export interface Person {
    id?: number;
    name: string;
    lastName: string;
    pin: string;
    gender?: string;
    age?: number;
}