export interface ValidationResponse {
    isSuccess: boolean;
    message: string;
}